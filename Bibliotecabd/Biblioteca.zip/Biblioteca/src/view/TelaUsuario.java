package view;

import controller.UsuarioController;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Usuario;

public class TelaUsuario extends JFrame {

    private JTextField txtNome, txtMatricula, txtEmail, txtId;
    private JTable tabela;
    private DefaultTableModel modelo;
    private UsuarioController controller;

    public TelaUsuario() {
        super("Gerenciar Usuários");
        controller = new UsuarioController();

        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // 🔹 Painel de Formulário
        JPanel painelForm = new JPanel(new GridLayout(5, 2, 5, 5));
        painelForm.setBorder(BorderFactory.createTitledBorder("Cadastro / Atualização de Usuário"));

        txtId = new JTextField();
        txtId.setEditable(false);
        txtNome = new JTextField();
        txtMatricula = new JTextField();
        txtEmail = new JTextField();

        painelForm.add(new JLabel("ID:"));
        painelForm.add(txtId);
        painelForm.add(new JLabel("Nome:"));
        painelForm.add(txtNome);
        painelForm.add(new JLabel("Matrícula:"));
        painelForm.add(txtMatricula);
        painelForm.add(new JLabel("Email:"));
        painelForm.add(txtEmail);

        add(painelForm, BorderLayout.NORTH);

        // 🔹 Painel de Botões
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        JButton btnCadastrar = new JButton("Cadastrar");
        JButton btnAtualizar = new JButton("Atualizar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnListar = new JButton("Listar Usuários");

        painelBotoes.add(btnCadastrar);
        painelBotoes.add(btnAtualizar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnListar);

        add(painelBotoes, BorderLayout.SOUTH);

        // 🔹 Tabela
        modelo = new DefaultTableModel(new Object[]{"ID", "Nome", "Matrícula", "Email"}, 0);
        tabela = new JTable(modelo);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        // 🔹 Eventos dos botões
        btnCadastrar.addActionListener(e -> cadastrarUsuario());
        btnListar.addActionListener(e -> listarUsuarios());
        btnExcluir.addActionListener(e -> excluirUsuario());
        btnAtualizar.addActionListener(e -> atualizarUsuario());

        // 🔹 Quando clicar em uma linha, preencher os campos
        tabela.getSelectionModel().addListSelectionListener(e -> preencherCampos());
    }

    private void cadastrarUsuario() {
        controller.cadastrarUsuario(txtNome.getText(), txtMatricula.getText(), txtEmail.getText());
        listarUsuarios();
        limparCampos();
    }

    private void listarUsuarios() {
        modelo.setRowCount(0);
        List<Usuario> usuarios = controller.listarUsuarios();
        if (usuarios != null) {
            for (Usuario u : usuarios) {
                modelo.addRow(new Object[]{u.getId(), u.getNome(), u.getMatricula(), u.getEmail()});
            }
        }
    }

    private void preencherCampos() {
        int linha = tabela.getSelectedRow();
        if (linha != -1) {
            txtId.setText(tabela.getValueAt(linha, 0).toString());
            txtNome.setText(tabela.getValueAt(linha, 1).toString());
            txtMatricula.setText(tabela.getValueAt(linha, 2).toString());
            txtEmail.setText(tabela.getValueAt(linha, 3).toString());
        }
    }

    private void atualizarUsuario() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Selecione um usuário na tabela para atualizar!");
            return;
        }

        int id = Integer.parseInt(txtId.getText());
        controller.atualizarUsuario(id, txtNome.getText(), txtMatricula.getText(), txtEmail.getText());
        listarUsuarios();
        limparCampos();
    }

    private void excluirUsuario() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Selecione um usuário na tabela para excluir!");
            return;
        }

        int id = Integer.parseInt(txtId.getText());
        controller.deletarUsuario(id);
        listarUsuarios();
        limparCampos();
    }

    private void limparCampos() {
        txtId.setText("");
        txtNome.setText("");
        txtMatricula.setText("");
        txtEmail.setText("");
    }
}
