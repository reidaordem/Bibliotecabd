package view;

import javax.swing.*;
import java.awt.*;

public class MenuPrincipal extends JFrame {

    public MenuPrincipal() {
        super("📚 Sistema da Biblioteca");

        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1, 10, 10));

        JLabel titulo = new JLabel("Sistema de Gerenciamento de Biblioteca", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 15));

        JButton btnUsuarios = new JButton("👤 Gerenciar Usuários");
        JButton btnLivros = new JButton("📖 Gerenciar Livros");
        JButton btnEmprestimos = new JButton("📦 Gerenciar Empréstimos");

        // 🔸 Ações dos botões
        btnUsuarios.addActionListener(e -> new TelaUsuario().setVisible(true));
        btnLivros.addActionListener(e -> new TelaLivro().setVisible(true));
        btnEmprestimos.addActionListener(e -> new TelaEmprestimo().setVisible(true));

        add(titulo);
        add(btnUsuarios);
        add(btnLivros);
        add(btnEmprestimos);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}
