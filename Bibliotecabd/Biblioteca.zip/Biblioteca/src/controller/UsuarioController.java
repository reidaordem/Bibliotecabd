package controller;

import java.util.List;
import javax.swing.JOptionPane;
import model.Usuario;
import service.UsuarioService;

public class UsuarioController {

    private UsuarioService usuarioService;

    public UsuarioController() {
        this.usuarioService = new UsuarioService();
    }

    // 🔸 Cadastrar novo usuário
    public void cadastrarUsuario(String nome, String matricula, String email) {
        if (nome.isEmpty() || matricula.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(null, "⚠️ Todos os campos são obrigatórios!");
            return;
        }

        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setMatricula(matricula);
        usuario.setEmail(email);

        usuarioService.cadastrarUsuario(usuario);
    }

    // 🔸 Listar todos os usuários
    public List<Usuario> listarUsuarios() {
        return usuarioService.listarUsuarios();
    }

    // 🔸 Atualizar usuário existente
    public void atualizarUsuario(int id, String nome, String matricula, String email) {
        Usuario usuario = new Usuario();
        usuario.setId(id);
        usuario.setNome(nome);
        usuario.setMatricula(matricula);
        usuario.setEmail(email);

        usuarioService.atualizarUsuario(usuario);
    }

    // 🔸 Deletar usuário
    public void deletarUsuario(int id) {
        int opcao = JOptionPane.showConfirmDialog(null, 
            "Tem certeza que deseja excluir o usuário com ID " + id + "?", 
            "Confirmação", 
            JOptionPane.YES_NO_OPTION);

        if (opcao == JOptionPane.YES_OPTION) {
            usuarioService.deletarUsuario(id);
        }
    }
}
