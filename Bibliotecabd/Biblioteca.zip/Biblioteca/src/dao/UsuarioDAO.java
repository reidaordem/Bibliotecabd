package dao;

import java.sql.*;     // Importa todas as classes do pacote java.sql
import java.util.*;    // Importa listas, ArrayList, etc.
import model.Usuario;  // Importa nossa classe de modelo

public class UsuarioDAO {

    // CREATE
    public void inserir(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO Usuario (nome, matrícula, email) VALUES (?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getMatricula());
            stmt.setString(3, usuario.getEmail());
            stmt.executeUpdate();
        }
    }

    // READ (Listar todos)
    public List<Usuario> listarTodos() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM Usuario";

        try (Connection conn = ConnectionFactory.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Usuario u = new Usuario(
                    rs.getInt("ID"),
                    rs.getString("nome"),
                    rs.getString("matrícula"),
                    rs.getString("email")
                );
                usuarios.add(u);
            }
        }
        return usuarios;
    }

    // UPDATE
    public void atualizar(Usuario usuario) throws SQLException {
        String sql = "UPDATE Usuario SET nome=?, matrícula=?, email=? WHERE ID=?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getMatricula());
            stmt.setString(3, usuario.getEmail());
            stmt.setInt(4, usuario.getId());
            stmt.executeUpdate();
        }
    }

    // DELETE
    public void deletar(int id) throws SQLException {
        String sql = "DELETE FROM Usuario WHERE ID=?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
