package dao;
import java.sql.*;
import java.util.*;
import model.Emprestimo;

public class EmprestimoDAO {

    // CREATE
    public void inserir(Emprestimo emprestimo) throws SQLException {
        String sql = "INSERT INTO Emprestimo (id_usuario, id_livro, retirada, devolucao, multa, devolvido) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, emprestimo.getIdUsuario());
            stmt.setInt(2, emprestimo.getIdLivro());
            stmt.setDate(3, java.sql.Date.valueOf(emprestimo.getRetirada()));
            stmt.setDate(4, java.sql.Date.valueOf(emprestimo.getDevolucao()));
            stmt.setDouble(5, emprestimo.getMulta());
            stmt.setBoolean(6, emprestimo.isDevolvido());

            stmt.executeUpdate();
        }
    }

    // READ
    public List<Emprestimo> listarTodos() throws SQLException {
        List<Emprestimo> emprestimos = new ArrayList<>();
        String sql = "SELECT * FROM Emprestimo";

        try (Connection conn = ConnectionFactory.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Emprestimo e = new Emprestimo(
                    rs.getInt("ID"),
                    rs.getInt("id_usuario"),
                    rs.getInt("id_livro"),
                    rs.getDate("retirada").toLocalDate(),
                    rs.getDate("devolucao").toLocalDate(),
                    rs.getDouble("multa"),
                    rs.getBoolean("devolvido")
                );
                emprestimos.add(e);
            }
        }
        return emprestimos;
    }

    // UPDATE
    public void atualizar(Emprestimo emprestimo) throws SQLException {
    String sql = "UPDATE Emprestimo SET id_usuario=?, id_livro=?, retirada=?, devolucao=?, multa=?, devolvido=? WHERE ID=?";
    try (Connection conn = ConnectionFactory.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, emprestimo.getIdUsuario());
        stmt.setInt(2, emprestimo.getIdLivro());
        stmt.setDate(3, java.sql.Date.valueOf(emprestimo.getRetirada()));
        stmt.setDate(4, java.sql.Date.valueOf(emprestimo.getDevolucao()));
        stmt.setDouble(5, emprestimo.getMulta());
        stmt.setBoolean(6, emprestimo.isDevolvido());
        stmt.setInt(7, emprestimo.getId());

        stmt.executeUpdate();
    }
}


    // DELETE
    public void deletar(int id) throws SQLException {
        String sql = "DELETE FROM Emprestimo WHERE ID=?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }



// EmprestimoDAO.java
public Emprestimo buscarPorId(int id) throws SQLException {
    String sql = "SELECT * FROM Emprestimo WHERE ID = ?";
    Emprestimo e = null;

    try (Connection conn = ConnectionFactory.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            e = new Emprestimo();
            e.setId(rs.getInt("ID"));
            e.setIdUsuario(rs.getInt("id_usuario"));
            e.setIdLivro(rs.getInt("id_livro"));
            e.setRetirada(rs.getDate("retirada").toLocalDate());
            e.setDevolucao(rs.getDate("devolucao").toLocalDate());
            e.setMulta(rs.getDouble("multa"));
            e.setDevolvido(rs.getBoolean("devolvido"));
        }
    }
    return e;
}



}
